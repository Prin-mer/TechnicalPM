
import React from "react";
import palmpayLogo from "./assets/palmpay.png";
import unionbankLogo from "./assets/unionbank.png";

export default function App() {
  return (
    <div className="p-4 font-sans text-gray-800 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Nkem Moye</h1>

      <div className="flex items-center space-x-2 mb-2">
        <img src={palmpayLogo} alt="Palmpay Logo" className="w-6 h-6" />
        <h2 className="font-semibold">PalmPay</h2>
      </div>
      <p className="text-sm mb-4">
        IT Project Manager (Sep 2023 - Present, Lagos, Nigeria) <br />
        Reviewing and debugging API and URLs before pilot and deployment. <br />
        Project/Product Management. Business Process Re-engineering.<br />
        Facilitating business and tech communication.
      </p>

      <div className="flex items-center space-x-2 mb-2">
        <img src={unionbankLogo} alt="Union Bank Logo" className="w-6 h-6" />
        <h2 className="font-semibold">Union Bank</h2>
      </div>
      <p className="text-sm mb-4">
        Business Analyst (Sep 2020 - Aug 2023, Lagos) <br />
        Process Re-engineering, SOP analysis, automation with RPA, and DAP support.
      </p>

      <a
        href="https://www.linkedin.com/in/nkemmoye/"
        className="text-blue-600 underline"
        target="_blank"
        rel="noopener noreferrer"
      >
        See more on LinkedIn
      </a>
    </div>
  );
}
